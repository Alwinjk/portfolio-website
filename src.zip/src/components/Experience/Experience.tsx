import { Box, Typography } from "@mui/material";
import AnimatedSkillStack from "../Animations/AnimatedSkillStack";


export default function Experience() {


    return (
        <Box
            sx={{
                display: 'flex',
                flexDirection: {xs: 'column', sm: 'column', md: 'row'},
                px: {xs: 2, sm: 6, md: 20},
                gap: 4
            }}
        > 
            {/* Current job title section */}
            <Box 
                sx={{
                    display: 'flex',
                    flexDirection: 'column',
                    // justifyContent: { xs: 'center', sm: 'center', md: 'left'},
                    // alignItems: {xs: 'center', sm: 'center', md: 'left'},
                    my: 14
                }}
            >
                <Typography
                    variant="h1"
                    sx={{
                        fontWeight: 500,
                        fontSize: { xs: '2.0rem', sm: '2.0rem', md: '4rem' },
                        color: 'rgb(112, 102, 102)'
                    }}
                >
                    CURRENT ROLE
                </Typography>

                <Typography
                    variant="h2"
                    sx={{
                        fontWeight: 300,
                        fontSize: { xs: '2.0rem', sm: '2.0rem', md: '1.5rem' },
                        color: '#00000',
                        my: 14
                    }}
                >
                    Software Developer @ Tata Consultancy Services Canada Inc.
                </Typography>
            </Box>

            {/* Animated skill section */}
            <Box
                sx={{
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    my: 14
                }}
            >
                <AnimatedSkillStack />
            </Box>

            {/* Count Icons section */}
            <Box

            >

            </Box>
        </Box>
    )
}