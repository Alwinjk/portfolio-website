import '@fontsource/protest-guerrilla'; // default weight (usually 400)

import Header from "./components/Header/Header";
import Main from './components/Main/Main';

function App() {
  return (
    <div className="App">
      <Header />
      <Main />
    </div>
  );
}

export default App;
